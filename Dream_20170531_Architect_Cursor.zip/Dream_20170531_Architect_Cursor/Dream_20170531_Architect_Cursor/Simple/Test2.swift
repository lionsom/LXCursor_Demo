//
//  Test2.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit


//泛型
class Dream_BaseModel<T> : NSObject {
    
    var data:Array<T>?
    
}


//Array嵌套Array
//后面典型：MVP架构设计(泛型嵌套)
class Dream_UserModel<T> : Dream_BaseModel<Array<T>> {
    
}

class Test2: NSObject {

    //输出自定义数组
    
    
    //Swift语言析构函数:释放资源
    deinit {
        
    }
    
}








