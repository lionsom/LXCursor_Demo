//
//  Test.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

class BaseModel: NSObject {
    
    var age:Int = 100
    
}

//学生
class StudentModel: BaseModel {
    
}

class Test: NSObject {

    //比较两个对象年龄大小
    //上一节课讲解内容
    //第一种方式
//    func change<T : BaseModel>(a:inout T,b:inout T) {
//        
//    }
    
    
    
    //加入class申明：表示类方法(直接通过类名调用)
    //第二种方式:where语句实现
    class func change<T>(a:T,b:T) where T : BaseModel {
        if a.age == b.age {
            print("年龄相等，非常适合，相差5天")
        }else{
            print("不适合")
        }
    }
    
}
