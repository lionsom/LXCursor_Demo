//
//  ViewController.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //案例一：测试
        //以下写法正确
//        let someBody = StudentModel()
//        someBody.age = 100
//        let flonger = StudentModel()
//        flonger.age = 150
//        Test.change(a: someBody, b: flonger)
        
        //案例二：测试
        //以下写法错误，类型不匹配
//        let a = 100
//        let b = 200
//        Test.change(a: a, b: b)
        
        
        
        //案例三：迭代器模式-测试
//        let array = Dream_ConcreteAggegate<String>()
//        array.add(obj: "Dream")
//        array.add(obj: "andy")
//        array.add(obj: "wolfie")
//        array.add(obj: "rayman")
//        array.add(obj: "lakerszhang")
//        array.add(obj: "nick")
//        
//        let iterator = array.iterator()
//        while iterator.hasNext() {
//            //??:表示如果返回没有，那么给一个默认值
//            print(iterator.next() ?? "")
//        }
        
        
        //案例四：普通案例测试
        //天猫订单遍历
//        let tianMao = TianMaoOrder()
//        let array = tianMao.getArray()
//        for item in array {
//            print(item.orderId ?? "")
//            print(item.orderName ?? "")
//            print(item.orderPrice)
//            print(item.orderDetail ?? "")
//        }
//        //潭州订单遍历(数据库框架设计)
//        let tanZhou = TanZhouOrder()
//        let set = tanZhou.getArray()
//        for item in set {
//            print(item.orderId ?? "")
//            print(item.orderName ?? "")
//            print(item.orderPrice)
//            print(item.orderDetail ?? "")
//        }
        //京东订单遍历
        
        
        //案例五：优化代码
        let tianMao = Dream_TianMaoAggregate()
        let tanZhou = Dream_TanZhouAggregate()
        printModel(iterator: tianMao.getIterator())
        printModel(iterator: tanZhou.getIterator())
    }
    
    func printModel(iterator:Dream_OrderIteratorProtocol){
        while iterator.hasNext() {
            let model = iterator.next()
            print(model?.orderId ?? "")
            print(model?.orderName ?? "")
            print(model?.orderPrice ?? 0)
            print(model?.orderDetail ?? "")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

