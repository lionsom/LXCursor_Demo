//
//  Dream_AggregateProtocol.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

//现在自己搞这些迭代器协议
//之后坐框架设计时候，直接采用系统提供的迭代器
protocol Dream_AggregateProtocol {
    
    associatedtype DataType
    //添加元素
    func add(obj:DataType)
    //删除元素
    func remove(index:Int)
    //获取迭代器
    func iterator() -> Dream_AnyIterator<DataType>
}
