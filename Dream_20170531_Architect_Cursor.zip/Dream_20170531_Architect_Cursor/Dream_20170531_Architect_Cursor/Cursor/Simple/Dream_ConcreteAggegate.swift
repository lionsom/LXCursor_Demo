//
//  Dream_ConcreteAggegate.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

class Dream_ConcreteAggegate<T>: Dream_AggregateProtocol {

    typealias DataType = T
    
    private var array = Array<T>()
    
    func add(obj: T) {
        self.array.append(obj)
    }
    
    func remove(index: Int) {
        self.array.remove(at: index)
    }
    
    func iterator() -> Dream_AnyIterator<T> {
        return Dream_ConcreteIterator<T>(array: self.array)
    }
    
}
