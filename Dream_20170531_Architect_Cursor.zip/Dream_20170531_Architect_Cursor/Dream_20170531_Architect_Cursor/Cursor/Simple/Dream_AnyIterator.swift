//
//  Dream_AnyIterator.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

//默认实现
class Dream_AnyIterator<T>: Dream_IteratorProtocol {
 
    typealias ItemType = T
    
    var array:Array<T>?
    //下标:用于记录当前遍历位置
    var index:Int = 0
    
    init(array:Array<T>) {
        self.array = array
    }
    
    func next() -> T? {
        return nil
    }
    
    func hasNext() -> Bool {
        return false
    }
    
}
