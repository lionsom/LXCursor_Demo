//
//  Dream_IteratorProtocol.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

//迭代器接口(协议)
protocol Dream_IteratorProtocol {
    
    //遍历元素你知道是什么类型?
    //泛型编程
    associatedtype ItemType
    //下一个元素
    func next() -> ItemType?
    //是否有元素
    func hasNext() -> Bool
    
}
