//
//  Dream_OrderIterator.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

class Dream_OrderIterator<T>: Dream_OrderIteratorProtocol {
    
    //抽象属性，子类使用
    var obj:T?
    var index:Int = 0
    
    init(obj:T) {
        self.obj = obj
    }
    
    func next() -> OrderModel? {
        return nil
    }
    
    func hasNext() -> Bool {
        return false
    }
    
}
