//
//  Dream_TanZhouAggregate.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

//潭州订单容器
class Dream_TanZhouAggregate: NSObject {

    //采用的是Array数组保存
    private var set = Set<OrderModel>()
    
    override init() {
        super.init()
        self.set.insert(OrderModel(orderId: "1", orderName: "买了皮鞋", orderPrice: 998, orderDetail: "男士帅气需要"))
        self.set.insert(OrderModel(orderId: "2", orderName: "买了衬衣", orderPrice: 668, orderDetail: "男士帅气需要"))
        self.set.insert(OrderModel(orderId: "3", orderName: "买了MacPro", orderPrice: 16880, orderDetail: "装逼神奇"))
    }
    
    func getIterator()->Dream_OrderIteratorProtocol{
        return Dream_TanZhouIterator(set: self.set)
    }
    
}
