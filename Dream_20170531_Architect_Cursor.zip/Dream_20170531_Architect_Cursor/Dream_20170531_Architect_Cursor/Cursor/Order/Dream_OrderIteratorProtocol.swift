//
//  Dream_OrderIteratorProtocol.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

protocol Dream_OrderIteratorProtocol {
    
    //下一个元素
    func next() -> OrderModel?
    //是否有元素
    func hasNext() -> Bool
    
}

