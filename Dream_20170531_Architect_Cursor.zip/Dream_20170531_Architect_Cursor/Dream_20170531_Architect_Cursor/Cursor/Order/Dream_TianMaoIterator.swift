//
//  Dream_TianMaoIterator.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

//天猫迭代器(子类：决定具体的类型)
class Dream_TianMaoIterator: Dream_OrderIterator<Array<OrderModel>> {

    init(array: Array<OrderModel>) {
        super.init(obj: array)
    }

    override func next() -> OrderModel? {
        if self.hasNext() {
            let result = self.obj?[self.index];
            index += 1
            return result
        }
        return nil
    }
    
    override func hasNext() -> Bool {
        return index != self.obj?.count
    }
    
}
