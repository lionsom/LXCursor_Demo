//
//  OrderModel.swift
//  Dream_20170531_Architect_Cursor
//
//  Created by Dream on 2017/5/31.
//  Copyright © 2017年 Tz. All rights reserved.
//

import UIKit

class OrderModel: NSObject {

    var orderId:String?
    var orderName:String?
    var orderPrice:Int = 0
    var orderDetail:String?
    
    init(orderId:String,orderName:String,orderPrice:Int,orderDetail:String) {
        super.init()
        self.orderId = orderId
        self.orderName = orderName
        self.orderPrice = orderPrice
        self.orderDetail = orderDetail
    }
    
}
